# Demo of workflow in R projects

Implementing a **Reproducible Research** workflow in the R-ecosystem

## Motivation

This project serves to provide a simple, yet illustrative example of an R project which adheres to the principles of reproducible research. 

The aim is to provide a working example for teaching R to Ph.D students

## Repository overview

The file structure should be relatively straight forward and folder titles self-explanatory, but note:

* The folder manuscripts is intended for snap-shot copies for the working directory (except it 'manuscripts' itself) that generate the submitted manuscripts. Create a subfolder for each journal if necessary until accepted and published.

## Raw data structure

The raw data is stored in a single file ../raw_data/raw_data_file.csv

"id"      : unique id relating to the study participant
"date"    : date of the test
"tester"  : one of two possible testers
"sex"     : participants sex
"age"     : participants age
"height"  : participants height
"weight"  : participants weight
"session" : each participants partoke in two sessions on different days
          : one session with and one without local anaesthesia
"ppt1"    : pressure pain threshold measure #1
"ppt2"    : pressure pain threshold measure #2
"ppt3"    : pressure pain threshold measure #3
"test"    : in each session, participants partoke in two tests
"probe"   : only relevant for pressure probe: flat head or round head
"ts1"     : pain intensity with first pressure probe application
"ts10"    : pain intensity with tenth pressure probe application

## Running instructions


## More resources


## About

This sub-project is part of the Ph.D course in Basic Data Science using R and Tidyverse, which is a collaborative effort between Steen Harsted and Søren O'Neill.
