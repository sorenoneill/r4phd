my_summary_stats <- function(some_data) {
require("tidyverse")

tmp_data <- some_data %>% 
  select(Sex=sex, age, height, weight) %>% 
  group_by(Sex) %>% 
  summarise(`Mean age`=round(mean(age),2), 
            `Mean height`=round(mean(height),2), 
            `Mean_weight`=round(mean(weight),2))

return(knitr::kable(tmp_data))
}
